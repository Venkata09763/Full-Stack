const express = require('express');
const cors = require('cors');
const path = require('path');
const nodemailer = require('nodemailer');
const { Client } = require('pg'); // using the standard PG driver to connect to H2

require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Database Setup
// Connect to H2 Database using PostgreSQL mode (default port 5435)
const client = new Client({
    host: '127.0.0.1',
    port: 5435,
    user: 'sa',
    password: '',
    database: 'test'
});

client.connect()
    .then(() => {
        console.log('Connected to the H2 database (via PostgreSQL Compatibility Mode).');
        
        // Initialize Tables
        const initQueries = `
            CREATE TABLE IF NOT EXISTS users (
                id VARCHAR(255) PRIMARY KEY,
                name VARCHAR(255),
                email VARCHAR(255) UNIQUE,
                password VARCHAR(255)
            );

            CREATE TABLE IF NOT EXISTS events (
                id VARCHAR(255) PRIMARY KEY,
                title VARCHAR(255),
                date VARCHAR(255),
                location VARCHAR(255),
                description TEXT
            );
            
            CREATE TABLE IF NOT EXISTS enrollments (
                id VARCHAR(255) PRIMARY KEY,
                eventId VARCHAR(255),
                name VARCHAR(255),
                email VARCHAR(255),
                timestamp VARCHAR(255),
                FOREIGN KEY(eventId) REFERENCES events(id) ON DELETE CASCADE
            );
        `;

        client.query(initQueries)
            .then(() => {
                // Seed admin user
                client.query("SELECT * FROM users WHERE email = 'admin@admin.com'")
                    .then(res => {
                        if (res.rows.length === 0) {
                            client.query("INSERT INTO users (id, name, email, password) VALUES ($1, $2, $3, $4)", ["admin-001", "Administrator", "admin@admin.com", "admin123"])
                                .then(() => console.log('Admin user seeded.'))
                                .catch(err => console.error(err));
                        }
                    })
                    .catch(err => console.error('Admin seed check error:', err));

                // Seed events if empty
                client.query(`SELECT COUNT(*) as count FROM events LIMIT 1`)
                    .then(res => {
                        if (res.rows[0].count == 0) {
                            const insertSql = 'INSERT INTO events (id, title, date, location, description) VALUES ($1, $2, $3, $4, $5)';
                            client.query(insertSql, ["1", "Annual Tech Fest 2026", "2026-05-20", "Main Auditorium", "Join us for the biggest technology festival on campus featuring coding competitions, guest lectures, and more."])
                                .catch(err => console.error(err));
                            client.query(insertSql, ["2", "Career Fair", "2026-06-05", "Sports Complex", "Meet top recruiters from tech companies and secure your dream internship or job."])
                                .catch(err => console.error(err));
                            console.log('Database seeded with initial events.');
                        }
                    })
                    .catch(err => console.error('Seed check error:', err));
            })
            .catch(err => console.error('Table creation error:', err));
    })
    .catch(err => {
        console.error('Error connecting to H2 Database. Please ensure start-database.bat is running!');
        console.error(err.message);
    });

// Nodemailer Setup
let transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
    }
});
console.log("Live email delivery system initialized via Gmail SMTP.");

// API Routes

// 1. Get all events
app.get('/api/events', (req, res) => {
    client.query('SELECT * FROM events ORDER BY date ASC')
        .then(result => {
            res.status(200).json(result.rows);
        })
        .catch(err => {
            res.status(500).json({ error: "Failed to retrieve events." });
        });
});

// 2. Create a new event
app.post('/api/events', (req, res) => {
    const { title, date, location, description } = req.body;
    
    if (!title || !date || !location || !description) {
        return res.status(400).json({ error: "All fields are required to create an event." });
    }

    const newEvent = {
        id: Date.now().toString(),
        title,
        date,
        location,
        description
    };

    const insertSql = `INSERT INTO events (id, title, date, location, description) VALUES ($1, $2, $3, $4, $5)`;
    client.query(insertSql, [newEvent.id, newEvent.title, newEvent.date, newEvent.location, newEvent.description])
        .then(() => {
            res.status(201).json(newEvent);
        })
        .catch(err => {
            return res.status(500).json({ error: "Failed to create event." });
        });
});

// 2.5 Delete an event
app.delete('/api/events/:id', (req, res) => {
    const eventId = req.params.id;
    client.query('DELETE FROM events WHERE id = $1', [eventId])
        .then(() => {
            res.status(200).json({ message: "Event deleted successfully." });
        })
        .catch(err => {
            res.status(500).json({ error: "Failed to delete event." });
        });
});

// 3. Enroll in an event
app.post('/api/events/:id/enroll', (req, res) => {
    const eventId = req.params.id;
    const { name, email } = req.body;

    if (!name || !email) {
        return res.status(400).json({ error: "Name and email are required to enroll." });
    }

    // Check if event exists
    client.query('SELECT * FROM events WHERE id = $1', [eventId])
        .then(result => {
            if (result.rows.length === 0) {
                return res.status(404).json({ error: "Event not found." });
            }

            const eventExists = result.rows[0];
            const newEnrollment = {
                id: Date.now().toString(),
                eventId,
                name,
                email,
                timestamp: new Date().toISOString()
            };

            const insertEnrol = `INSERT INTO enrollments (id, eventId, name, email, timestamp) VALUES ($1, $2, $3, $4, $5)`;
            client.query(insertEnrol, [newEnrollment.id, newEnrollment.eventId, newEnrollment.name, newEnrollment.email, newEnrollment.timestamp])
                .then(() => {
                    // Send email using Nodemailer
                    if (transporter) {
                        let mailOptions = {
                            from: `"Smart Campus Events" <${process.env.EMAIL_USER}>`,
                            to: email, // The user's input email
                            subject: `Enrollment Confirmed: ${eventExists.title}`,
                            text: `Hello ${name},\n\nYou successfully enrolled in ${eventExists.title}.\nDate: ${eventExists.date}\nLocation: ${eventExists.location}\n\nSee you there!\n\nSmart Campus Team`,
                            html: `<p>Hello <b>${name}</b>,</p><p>You successfully enrolled in <b>${eventExists.title}</b>.</p><p><b>Date:</b> ${eventExists.date}<br><b>Location:</b> ${eventExists.location}</p><p>See you there!</p><p>Best,<br>Smart Campus Team</p>`
                        };
                        
                        transporter.sendMail(mailOptions, (error, info) => {
                            if (error) {
                                console.error("Error sending mail:", error);
                            } else {
                                console.log("Live email successfully sent to %s (Message ID: %s)", email, info.messageId);
                            }
                        });
                    }

                    res.status(201).json({ message: "Successfully enrolled!", enrollment: newEnrollment });
                })
                .catch(err => {
                    return res.status(500).json({ error: "Failed to enroll in event." });
                });
        })
        .catch(err => {
            return res.status(500).json({ error: "Database error checking event." });
        });
});

// 4. Get enrolled events by email
app.get('/api/enrollments', (req, res) => {
    const email = req.query.email;
    if (!email) {
        return res.status(400).json({ error: "Email query parameter is required." });
    }

    const query = `
        SELECT e.*, 
               ev.title as ev_title, 
               ev.date as ev_date, 
               ev.location as ev_location 
        FROM enrollments e 
        LEFT JOIN events ev ON e.eventId = ev.id 
        WHERE e.email = $1
        ORDER BY e.timestamp DESC
    `;

    client.query(query, [email])
        .then(result => {
            const enrichedEnrollments = result.rows.map(enrol => {
                return {
                    id: enrol.id,
                    eventId: enrol.eventid, // postgres lowercase columns internally
                    name: enrol.name,
                    email: enrol.email,
                    timestamp: enrol.timestamp,
                    event: {
                        title: enrol.ev_title || "Unknown/Removed Event",
                        date: enrol.ev_date || "N/A",
                        location: enrol.ev_location || "N/A"
                    }
                };
            });

            res.status(200).json(enrichedEnrollments);
        })
        .catch(err => {
            console.error(err);
            return res.status(500).json({ error: "Failed to retrieve enrollments." });
        });
});

// 4.5 Delete enrollment
app.delete('/api/enrollments/:id', (req, res) => {
    const id = req.params.id;
    client.query('DELETE FROM enrollments WHERE id = $1', [id])
        .then(() => {
            res.status(200).json({ message: "Enrollment removed successfully" });
        })
        .catch(err => {
            res.status(500).json({ error: "Failed to remove enrollment" });
        });
});

// 4.6 Get all enrollments for admin
app.get('/api/admin/enrollments', (req, res) => {
    const query = `
        SELECT e.*, 
               ev.title as ev_title, 
               ev.date as ev_date, 
               ev.location as ev_location 
        FROM enrollments e 
        LEFT JOIN events ev ON e.eventId = ev.id 
        ORDER BY e.timestamp DESC
    `;

    client.query(query)
        .then(result => {
            const enrichedEnrollments = result.rows.map(enrol => {
                return {
                    id: enrol.id,
                    eventId: enrol.eventid, // postgres lowercase columns internally
                    name: enrol.name,
                    email: enrol.email,
                    timestamp: enrol.timestamp,
                    event: {
                        title: enrol.ev_title || "Unknown/Removed Event",
                        date: enrol.ev_date || "N/A",
                        location: enrol.ev_location || "N/A"
                    }
                };
            });

            res.status(200).json(enrichedEnrollments);
        })
        .catch(err => {
            console.error(err);
            return res.status(500).json({ error: "Failed to retrieve all enrollments." });
        });
});

// 5. Register User
app.post('/api/register', (req, res) => {
    const { name, email, password } = req.body;
    if (!name || !email || !password) {
        return res.status(400).json({ error: "All fields are required to register." });
    }

    const checkSql = 'SELECT * FROM users WHERE email = $1';
    client.query(checkSql, [email]).then(result => {
        if (result.rows.length > 0) {
            return res.status(400).json({ error: "Email is already registered." });
        }
        
        const id = Date.now().toString();
        const insertSql = 'INSERT INTO users (id, name, email, password) VALUES ($1, $2, $3, $4)';
        client.query(insertSql, [id, name, email, password]).then(() => {
            res.status(201).json({ id, name, email });
        }).catch(err => res.status(500).json({ error: "Failed to create user account." }));
    }).catch(err => res.status(500).json({ error: "Database error checking user." }));
});

// 6. Login User
app.post('/api/login', (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) {
        return res.status(400).json({ error: "Email and password are required." });
    }

    const sql = 'SELECT * FROM users WHERE email = $1 AND password = $2';
    client.query(sql, [email, password]).then(result => {
        if (result.rows.length === 0) {
            return res.status(401).json({ error: "Invalid email or password." });
        }
        const user = result.rows[0];
        const isAdmin = user.email === 'admin@admin.com';
        // Note: For a real production app, use JWT and hashed passwords.
        res.status(200).json({ id: user.id, name: user.name, email: user.email, isAdmin });
    }).catch(err => res.status(500).json({ error: "Database error during login." }));
});

// Start the Server
app.listen(PORT, () => {
    console.log(`Server is running beautifully on http://localhost:${PORT}`);
});
