@echo off
echo Starting H2 Database Server in PostgreSQL Compatibility Mode...
echo You can view the database by opening http://localhost:8082 in your browser.
java -cp h2.jar org.h2.tools.Server -tcp -tcpAllowOthers -pg -pgAllowOthers -web -webAllowOthers -webPort 8082 -baseDir ./db -ifNotExists
pause
