CREATE DATABASE IF NOT EXISTS smart_campus_db;
USE smart_campus_db;
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS enrollments;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS events;
SET FOREIGN_KEY_CHECKS = 1;

-- 1. Create Users Table
CREATE TABLE IF NOT EXISTS users (
    id VARCHAR(255) PRIMARY KEY,
    name VARCHAR(255),
    email VARCHAR(255) UNIQUE,
    password VARCHAR(255)
);

-- 2. Create Events Table
CREATE TABLE IF NOT EXISTS events (
    id VARCHAR(255) PRIMARY KEY,
    title VARCHAR(255),
    date VARCHAR(255),
    location VARCHAR(255),
    description TEXT
);

-- 3. Create Enrollments Table
CREATE TABLE IF NOT EXISTS enrollments (
    id VARCHAR(255) PRIMARY KEY,
    eventId VARCHAR(255),
    name VARCHAR(255),
    email VARCHAR(255),
    timestamp VARCHAR(255),
    FOREIGN KEY(eventId) REFERENCES events(id) ON DELETE CASCADE
);

-- 4. Seed Default Admin User
-- Note: Remove 'IGNORE' if running in H2 Web Console, keep if running in MySQL Workbench
INSERT IGNORE INTO users (id, name, email, password) 
VALUES ('admin-001', 'Administrator', 'admin@admin.com', 'admin123');

-- 5. Seed Sample Events
INSERT IGNORE INTO events (id, title, date, location, description) 
VALUES ('1', 'Annual Tech Fest 2026', '2026-05-20', 'Main Auditorium', 'Join us for the biggest technology festival on campus featuring coding competitions, guest lectures, and more.');

INSERT IGNORE INTO events (id, title, date, location, description) 
VALUES ('2', 'Career Fair', '2026-06-05', 'Sports Complex', 'Meet top recruiters from tech companies and secure your dream internship or job.');

SELECT * FROM events;
SELECT * FROM users;

