// Toggle between Login and Register views
function toggleAuth(type) {
    if (type === 'login') {
        document.getElementById('login-box').style.display = 'block';
        document.getElementById('register-box').style.display = 'none';
    } else {
        document.getElementById('login-box').style.display = 'none';
        document.getElementById('register-box').style.display = 'block';
    }
}

document.addEventListener('DOMContentLoaded', () => {
    // Check if already logged in
    const userEmail = localStorage.getItem('userEmail');
    if (userEmail) {
        if (localStorage.getItem('isAdmin') === 'true') {
            window.location.href = 'admin.html';
        } else {
            window.location.href = '/';
        }
    }

    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const loginError = document.getElementById('login-error');
    const regError = document.getElementById('reg-error');

    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        loginError.style.display = 'none';
        const email = document.getElementById('login-email').value;
        const password = document.getElementById('login-password').value;

        try {
            const res = await fetch('/api/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            });

            if (!res.ok) {
                const data = await res.json();
                throw new Error(data.error || 'Login failed');
            }

            const data = await res.json();
            localStorage.setItem('userEmail', data.email);
            localStorage.setItem('userName', data.name);
            if (data.isAdmin) {
                localStorage.setItem('isAdmin', 'true');
                window.location.href = 'admin.html';
            } else {
                localStorage.setItem('isAdmin', 'false');
                window.location.href = '/';
            }
        } catch (err) {
            loginError.innerText = err.message;
            loginError.style.display = 'block';
        }
    });

    registerForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        regError.style.display = 'none';
        const name = document.getElementById('reg-name').value;
        const email = document.getElementById('reg-email').value;
        const password = document.getElementById('reg-password').value;

        try {
            const res = await fetch('/api/register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name, email, password })
            });

            if (!res.ok) {
                const data = await res.json();
                throw new Error(data.error || 'Registration failed');
            }

            const data = await res.json();
            localStorage.setItem('userEmail', data.email);
            localStorage.setItem('userName', data.name);
            localStorage.setItem('isAdmin', 'false');
            window.location.href = '/';
        } catch (err) {
            regError.innerText = err.message;
            regError.style.display = 'block';
        }
    });
});
