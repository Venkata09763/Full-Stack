document.addEventListener('DOMContentLoaded', () => {
    const userEmail = localStorage.getItem('userEmail');
    const isAdmin = localStorage.getItem('isAdmin');

    if (!userEmail || isAdmin !== 'true') {
        window.location.href = 'login.html';
        return;
    }

    const tbody = document.getElementById('enrollments-tbody');

    async function loadAllEnrollments() {
        try {
            const res = await fetch('/api/admin/enrollments');
            if (!res.ok) {
                const data = await res.json();
                throw new Error(data.error || "Failed to fetch enrollments");
            }
            const data = await res.json();
            
            tbody.innerHTML = '';
            
            if (data.length === 0) {
                tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;">No enrollments found.</td></tr>';
                return;
            }

            data.forEach(enrol => {
                const tr = document.createElement('tr');
                const dateEnrolled = new Date(enrol.timestamp).toLocaleDateString();
                
                tr.innerHTML = `
                    <td>${enrol.name}</td>
                    <td>${enrol.email}</td>
                    <td><span class="highlight" style="font-weight: 500;">${enrol.event.title}</span></td>
                    <td>${enrol.event.date}</td>
                    <td>${dateEnrolled}</td>
                `;
                tbody.appendChild(tr);
            });
        } catch (e) {
            tbody.innerHTML = `<tr><td colspan="5" class="loading-state" style="text-align:center; color: var(--danger);">${e.message || "Error fetching enrollments."}</td></tr>`;
        }
    }

    window.logout = function() {
        localStorage.removeItem('userEmail');
        localStorage.removeItem('userName');
        localStorage.removeItem('isAdmin');
        window.location.href = 'login.html';
    };

    loadAllEnrollments();
});
