document.addEventListener('DOMContentLoaded', () => {
    const userEmail = localStorage.getItem('userEmail');
    const userName = localStorage.getItem('userName');

    if (!userEmail) {
        window.location.href = 'login.html';
        return;
    }

    if (localStorage.getItem('isAdmin') === 'true') {
        window.location.href = 'admin.html';
        return;
    }

    // Set greeting
    document.getElementById('user-greeting').innerText = `Hello, ${userName.split(' ')[0]}`;
    document.getElementById('user-controls').style.display = 'flex';

    const eventsList = document.getElementById('events-list');
    const addEventForm = document.getElementById('add-event-form');

    // Fetch Events
    async function loadEvents() {
        try {
            const res = await fetch('/api/events');
            const events = await res.json();
            
            eventsList.innerHTML = '';
            if (events.length === 0) {
                eventsList.innerHTML = '<p class="loading-state">No events found.</p>';
                return;
            }
            
            events.forEach(event => {
                const card = document.createElement('div');
                card.className = 'event-card';
                card.innerHTML = `
                    <h3>${event.title}</h3>
                    <p><strong>Date:</strong> ${event.date}</p>
                    <p><strong>Location:</strong> ${event.location}</p>
                    <p>${event.description}</p>
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 15px;">
                        <div id="enroll-container-${event.id}" class="enroll-container" style="margin: 0; width: 100%;">
                            <button onclick="showEnrollForm('${event.id}')">Enroll</button>
                        </div>
                        <button onclick="deleteEvent('${event.id}')" class="btn-cancel" style="margin: 0; margin-left: 10px; font-size: 0.8rem; padding: 6px 12px; white-space: nowrap;">Delete</button>
                    </div>
                `;
                eventsList.appendChild(card);
            });
        } catch (err) {
            eventsList.innerHTML = `<p class="loading-state">${err.message || 'Error loading events.'}</p>`;
        }
    }

    // Add Event
    addEventForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const newEvent = {
            title: document.getElementById('title').value,
            date: document.getElementById('date').value,
            location: document.getElementById('location').value,
            description: document.getElementById('description').value
        };

        try {
            const res = await fetch('/api/events', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(newEvent)
            });

            if (!res.ok) {
                const data = await res.json();
                throw new Error(data.error || "Failed to create event");
            }

            addEventForm.reset();
            loadEvents();
        } catch (err) {
            alert(err.message || "Error creating event");
        }
    });

    // Show inline form
    window.showEnrollForm = function(id) {
        const container = document.getElementById(`enroll-container-${id}`);
        container.innerHTML = `
            <form onsubmit="event.preventDefault(); submitEnroll('${id}');" class="inline-form">
                <input type="text" id="name-${id}" value="${userName}" required class="inline-input" readonly>
                <input type="email" id="email-${id}" value="${userEmail}" required class="inline-input" readonly>
                <div class="inline-actions">
                    <button type="submit" class="btn-primary" style="margin-top:0;">Confirm</button>
                    <button type="button" onclick="cancelEnroll('${id}')" class="btn-cancel" style="margin-top:0;">Cancel</button>
                </div>
            </form>
        `;
    };

    // Cancel inline form
    window.cancelEnroll = function(id) {
        const container = document.getElementById(`enroll-container-${id}`);
        container.innerHTML = `<button onclick="showEnrollForm('${id}')">Enroll</button>`;
    };

    // Submit Enrollment
    window.submitEnroll = async function(id) {
        const name = document.getElementById(`name-${id}`).value;
        const email = document.getElementById(`email-${id}`).value;
        
        if (name && email) {
            try {
                const res = await fetch(`/api/events/${id}/enroll`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ name, email })
                });
                
                if (!res.ok) {
                    const data = await res.json();
                    throw new Error(data.error || "Failed to enroll");
                }

                const container = document.getElementById(`enroll-container-${id}`);
                container.innerHTML = `<div class="success-msg"><i>✓</i> Successfully Enrolled!</div>`;
                
                // Refresh enrollments
                window.loadEnrollments();
            } catch(e) {
                alert(e.message || "Error processing enrollment, please try again.");
            }
        } else {
            alert("Please fill in both name and email fields.");
        }
    };

    // Check Enrollments
    window.loadEnrollments = async function() {
        const enrollmentsList = document.getElementById('my-enrollments-list');
        enrollmentsList.innerHTML = '<p class="loading-state">Fetching...</p>';

        try {
            const res = await fetch(`/api/enrollments?email=${encodeURIComponent(userEmail)}`);
            if (!res.ok) {
                const data = await res.json();
                throw new Error(data.error || "Failed to fetch enrollments");
            }
            const data = await res.json();
            
            enrollmentsList.innerHTML = '';
            
            if (data.length === 0) {
                enrollmentsList.innerHTML = '<p class="loading-state">No enrollments found for this email.</p>';
                return;
            }

            data.forEach(enrol => {
                const card = document.createElement('div');
                card.className = 'event-card';
                card.style.borderLeft = '4px solid var(--success)';
                card.innerHTML = `
                    <h3>${enrol.event.title}</h3>
                    <p><strong>Date:</strong> ${enrol.event.date}</p>
                    <p><strong>Location:</strong> ${enrol.event.location}</p>
                    <div style="margin-top: auto; padding-top: 15px; display: flex; justify-content: space-between; align-items: center; border-top: 1px solid var(--glass-border);">
                        <div style="color: var(--success); font-weight: 500; font-size: 0.95rem;">
                            <i>✓</i> Enrolled on ${new Date(enrol.timestamp).toLocaleDateString()}
                        </div>
                        <button onclick="removeEnrollment('${enrol.id}')" class="btn-cancel" style="padding: 4px 10px; font-size: 0.8rem; margin: 0;">Remove</button>
                    </div>
                `;
                enrollmentsList.appendChild(card);
            });
        } catch (e) {
            enrollmentsList.innerHTML = `<p class="loading-state">${e.message || "Error fetching enrollments."}</p>`;
        }
    };

    window.logout = function() {
        localStorage.removeItem('userEmail');
        localStorage.removeItem('userName');
        window.location.href = 'login.html';
    };

    window.removeEnrollment = async function(id) {
        if (!confirm("Are you sure you want to remove this enrollment?")) {
            return;
        }
        
        try {
            const res = await fetch(`/api/enrollments/${id}`, {
                method: 'DELETE'
            });
            
            if (!res.ok) {
                const data = await res.json();
                throw new Error(data.error || "Failed to remove enrollment");
            }
            
            // Reload enrollments after successful deletion
            window.loadEnrollments();
        } catch (e) {
            alert(e.message || "Error removing enrollment.");
        }
    };

    window.deleteEvent = async function(id) {
        if (!confirm("Are you sure you want to delete this event? This will also remove all enrollments for it.")) {
            return;
        }
        
        try {
            const res = await fetch(`/api/events/${id}`, {
                method: 'DELETE'
            });
            
            if (!res.ok) {
                const data = await res.json();
                throw new Error(data.error || "Failed to delete event");
            }
            
            // Reload events and enrollments to reflect deletion
            loadEvents();
            window.loadEnrollments();
        } catch (e) {
            alert(e.message || "Error deleting event.");
        }
    };

    loadEvents();
    loadEnrollments();
});
