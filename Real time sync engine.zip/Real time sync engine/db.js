const mysql = require("mysql2");

// ✅ Fix: Make sure these match your MySQL setup
// Default MySQL port is 3306 — change 3307 only if you're using a custom port (e.g. XAMPP on 3307)
// Add your MySQL password if one is set
const connection = mysql.createConnection({
  host: "127.0.0.1",
  user: "root",
  password: "your_password_here",       // ⚠️ Add your MySQL password here if required
  database: "realtime_sync",
  port: 3307      // ✅ Changed from 3307 to default 3306 (update if needed)
});

connection.connect((err) => {
  if (err) {
    console.error("Database connection failed:", err.message);
    process.exit(1); // ✅ Exit process on DB failure so errors are obvious
  } else {
    console.log("Connected to MySQL Database");
  }
});

module.exports = connection;