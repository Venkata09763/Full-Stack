const express = require("express");
const http = require("http");
const cors = require("cors");
const { Server } = require("socket.io");
const db = require("./db");

const app = express();
const server = http.createServer(app);

// ✅ Fixed: Added CORS config to Socket.IO
const io = new Server(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

app.use(cors());
app.use(express.json());
app.use(express.static("public"));

io.on("connection", (socket) => {
  console.log("User connected:", socket.id);

  socket.on("disconnect", () => {
    console.log("User disconnected:", socket.id);
  });
});

app.get("/events", (req, res) => {
  db.query("SELECT * FROM events ORDER BY id DESC", (err, result) => {
    if (err) return res.status(500).json(err);
    res.json(result);
  });
});

app.post("/events", (req, res) => {
  const { title, description } = req.body;

  // ✅ Fixed: Added basic validation
  if (!title || !description) {
    return res.status(400).json({ error: "Title and description are required" });
  }

  const sql = "INSERT INTO events (title, description) VALUES (?, ?)";
  db.query(sql, [title, description], (err, result) => {
    if (err) return res.status(500).json(err);

    const newEvent = {
      id: result.insertId,
      title,
      description,
    };

    io.emit("new_event", newEvent);
    res.json(newEvent);
  });
});

server.listen(3000, () => {
  console.log("Server running on http://localhost:3000");
});